# CMS

A self-learning project to create a Content Management System (CMS) that supports signup, login, posting, commenting, and admin privileges.

